import 'package:flutter/foundation.dart';
import '../model/user_model.dart';
import '../repository/auth_repository.dart';

class AuthViewModel extends ChangeNotifier {
  final AuthRepository _authRepository = AuthRepository();
  UserModel? _user;

  UserModel? get user => _user;

  AuthViewModel() {
    _authRepository.userChanges.listen((user) {
      _user = user;
      notifyListeners();
    });
  }

  Future<void> loginWithGoogle() async {
    _user = await _authRepository.signInWithGoogle();
    notifyListeners();
  }

  Future<void> logout() async {
    await _authRepository.signOut();
    _user = null;
    notifyListeners();
  }
}
