import 'package:flutter/material.dart';
import '../model/cliente.dart';
import '../repository/cliente_repository.dart';
import '../repository/cliente_repository_firebase.dart';
import '../utils/persistence_helper.dart';

class ClienteDTO {
  final int? codigo;
  final String cpf;
  final String nome;
  final String idade;
  final String dataNascimento;
  final String cidadeNascimento;
  final String subtitulo;

  ClienteDTO({
    required this.codigo,
    required this.cpf,
    required this.nome,
    required this.idade,
    required this.dataNascimento,
    required this.cidadeNascimento,
    required this.subtitulo,
  });

  factory ClienteDTO.fromModel(Cliente cliente) {
    return ClienteDTO(
      codigo: cliente.codigo,
      cpf: cliente.cpf,
      nome: cliente.nome,
      idade: cliente.idade.toString(),
      dataNascimento: cliente.dataNascimento,
      cidadeNascimento: cliente.cidadeNascimento,
      subtitulo: 'CPF: ${cliente.cpf} · ${cliente.cidadeNascimento}',
    );
  }

  Cliente toModel() {
    return Cliente(
      codigo: codigo,
      cpf: cpf,
      nome: nome,
      idade: int.tryParse(idade) ?? 0,
      dataNascimento: dataNascimento,
      cidadeNascimento: cidadeNascimento,
    );
  }
}

class ClienteViewModel extends ChangeNotifier {
  late IClienteRepository _repository;
  List<Cliente> _clientes = [];
  String _ultimoFiltro = '';
  bool _usandoFirebase = false;

  bool get usandoFirebase => _usandoFirebase;

  Future<void> init() async => await _init();

  Future<void> _init() async {
    _usandoFirebase = await PersistenceHelper.getUseFirebase();
    _repository = _usandoFirebase
        ? ClienteRepositoryFirebase()
        : ClienteRepository();
    await loadClientes();
  }

  Future<void> aplicarModo(bool usarFirebase) async {
    _usandoFirebase = usarFirebase;
    _repository = usarFirebase
        ? ClienteRepositoryFirebase()
        : ClienteRepository();
    await loadClientes(_ultimoFiltro);
    notifyListeners();
  }

  Future<void> togglePersistence() async {
    final current = await PersistenceHelper.getUseFirebase();
    final novoModo = !current;

    await PersistenceHelper.setUseFirebase(novoModo);
    _repository = novoModo ? ClienteRepositoryFirebase() : ClienteRepository();
    _usandoFirebase = novoModo;

    await loadClientes(_ultimoFiltro);
    notifyListeners();
  }

  List<ClienteDTO> get clientes =>
      _clientes.map((c) => ClienteDTO.fromModel(c)).toList();

  Future<void> loadClientes([String filtro = '']) async {
    _ultimoFiltro = filtro;
    _clientes = await _repository.buscar(filtro: filtro);
    notifyListeners();
  }

  Future<void> adicionarCliente({
    required String cpf,
    required String nome,
    required String idade,
    required String dataNascimento,
    required String cidadeNascimento,
  }) async {
    final cliente = Cliente(
      cpf: cpf,
      nome: nome,
      idade: int.tryParse(idade) ?? 0,
      dataNascimento: dataNascimento,
      cidadeNascimento: cidadeNascimento,
    );
    await _repository.inserir(cliente);
    await loadClientes(_ultimoFiltro);
  }

  Future<void> editarCliente({
    required int codigo,
    required String cpf,
    required String nome,
    required String idade,
    required String dataNascimento,
    required String cidadeNascimento,
  }) async {
    final cliente = Cliente(
      codigo: codigo,
      cpf: cpf,
      nome: nome,
      idade: int.tryParse(idade) ?? 0,
      dataNascimento: dataNascimento,
      cidadeNascimento: cidadeNascimento,
    );
    await _repository.atualizar(codigo, cliente);
    await loadClientes(_ultimoFiltro);
  }

  Future<void> removerCliente(int codigo) async {
    await _repository.excluir(codigo);
    await loadClientes(_ultimoFiltro);
  }
}
