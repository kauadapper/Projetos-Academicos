// viewmodel/camera_viewmodel.dart
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:convert';
import '../model/midia_model.dart';


class CameraViewModel {
  late CameraController _controller;
  bool _inicializado = false;
  MidiaModel? _ultimaMidia;

  CameraController get controller => _controller;
  bool get inicializado => _inicializado;
  String? get caminhoMidia => _ultimaMidia?.caminho;
  String? get base64Midia => _ultimaMidia?.base64;
  bool get ehVideo => _ultimaMidia?.ehVideo ?? false;
  bool get temMidia => _ultimaMidia != null;
  MidiaModel? get ultimaMidia => _ultimaMidia;

  /// Inicializa a camera usando a primeira camera disponivel.
  Future<void> inicializarCamera() async {
    final cameras = await availableCameras();
    if (cameras.isEmpty) {
      throw Exception('Nenhuma camera disponivel');
    }
    final primeira = cameras.first;
    _controller = CameraController(primeira, ResolutionPreset.medium,
        enableAudio: true);
    await _controller.initialize();
    _inicializado = true;
  }

  /// Tira foto, le bytes e gera base64.
  /// Nao salva em disco para manter compatibilidade web.
  Future<void> tirarFoto() async {
    if (!_inicializado) return;
    final XFile foto = await _controller.takePicture();
    final bytes = await foto.readAsBytes();
    final base64Str = base64Encode(bytes);

    // caminho mantido nulo (evita usar dart:io)
    _ultimaMidia = MidiaModel(caminho: null, base64: base64Str, ehVideo: false);
  }

  /// Inicia gravacao de video
  Future<void> iniciarGravacao() async {
    if (!_inicializado) return;
    if (!_controller.value.isRecordingVideo) {
      await _controller.startVideoRecording();
    }
  }

  /// Para gravacao e gera base64 do arquivo de video (pode ser grande)
  Future<void> pararGravacao() async {
    if (!_inicializado) return;
    if (_controller.value.isRecordingVideo) {
      final XFile video = await _controller.stopVideoRecording();

      final bytes = await video.readAsBytes();
      final base64Str = base64Encode(bytes);

      _ultimaMidia = MidiaModel(caminho: null, base64: base64Str, ehVideo: true);
    }
  }

  void dispose() {
    try {
      _controller.dispose();
    } catch (_) {}
  }
}
