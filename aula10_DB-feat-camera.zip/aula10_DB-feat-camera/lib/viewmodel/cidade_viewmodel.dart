import 'package:flutter/material.dart';
import '../repository/cidade_repository.dart';
import '../repository/cidade_repository_firebase.dart';
import '../db/cidade.dart';
import '../utils/persistence_helper.dart';

class CidadeViewModel extends ChangeNotifier {
  late ICidadeRepository _repository;
  List<Cidade> _cidades = [];
  String _ultimoFiltro = '';
  bool _usandoFirebase = false;

  Future<void> init() async => await _init();

  List<Cidade> get cidades => _cidades;

  bool get usandoFirebase => _usandoFirebase;

  Future<void> _init() async {
    final useFirebase = await PersistenceHelper.getUseFirebase();
    _usandoFirebase = useFirebase;
    _repository = useFirebase ? CidadeRepositoryFirebase() : CidadeRepository();
    await loadCidades();
  }

  Future<void> aplicarModo(bool usarFirebase) async {
    _usandoFirebase = usarFirebase;
    _repository = usarFirebase
        ? CidadeRepositoryFirebase()
        : CidadeRepository();
    await loadCidades(_ultimoFiltro);
    notifyListeners();
  }

  Future<void> togglePersistence() async {
    final current = await PersistenceHelper.getUseFirebase();
    final novoModo = !current;

    await PersistenceHelper.setUseFirebase(novoModo);
    _repository = novoModo ? CidadeRepositoryFirebase() : CidadeRepository();
    _usandoFirebase = novoModo;

    await loadCidades(_ultimoFiltro);
    notifyListeners();
  }

  Future<void> loadCidades([String filtro = '']) async {
    _ultimoFiltro = filtro;
    _cidades = await _repository.buscar(filtro: filtro);
    notifyListeners();
  }

  Future<void> adicionarCidade({
    required String nome,
    required String estado,
  }) async {
    await _repository.inserir(Cidade(nomeCidade: nome, estado: estado));
    await loadCidades(_ultimoFiltro);
  }

  Future<void> removerCidade(int id) async {
    await _repository.excluir(id);
    await loadCidades(_ultimoFiltro);
  }
}
