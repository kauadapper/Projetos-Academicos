import 'package:cloud_firestore/cloud_firestore.dart';
import '../model/cliente.dart';
import 'cliente_repository.dart';

class ClienteRepositoryFirebase implements IClienteRepository {
  final _collection = FirebaseFirestore.instance.collection('clientes');

  @override
  Future<void> inserir(Cliente cliente) async {
    await _collection.add(cliente.toMap());
  }

  @override
  Future<void> atualizar(int id, Cliente cliente) async {
    final doc = await _collection.where('codigo', isEqualTo: id).limit(1).get();

    if (doc.docs.isNotEmpty) {
      await _collection.doc(doc.docs.first.id).update(cliente.toMap());
    }
  }

  @override
  Future<void> excluir(int id) async {
    final doc = await _collection.where('codigo', isEqualTo: id).limit(1).get();

    if (doc.docs.isNotEmpty) {
      await _collection.doc(doc.docs.first.id).delete();
    }
  }

  @override
  Future<List<Cliente>> buscar({String filtro = ''}) async {
    final snapshot = await _collection.get();
    final all = snapshot.docs
        .map((doc) => Cliente.fromMap(doc.data()))
        .toList();

    if (filtro.isEmpty) return all;

    return all
        .where((c) => c.nome.toLowerCase().contains(filtro.toLowerCase()))
        .toList();
  }
}
