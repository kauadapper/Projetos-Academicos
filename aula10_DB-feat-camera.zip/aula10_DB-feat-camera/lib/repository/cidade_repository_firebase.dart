import 'package:cloud_firestore/cloud_firestore.dart';
import '../db/cidade.dart';
import 'cidade_repository.dart';

class CidadeRepositoryFirebase implements ICidadeRepository {
  final CollectionReference _collection = FirebaseFirestore.instance.collection(
    'cidades',
  );

  @override
  Future<void> inserir(Cidade cidade) async {
    await _collection.add(cidade.toMap());
  }

  @override
  Future<void> atualizar(int index, Cidade cidade) async {
    final snapshot = await _collection.get();
    if (index < snapshot.docs.length) {
      final docId = snapshot.docs[index].id;
      await _collection.doc(docId).update(cidade.toMap());
    }
  }

  @override
  Future<void> excluir(int index) async {
    final snapshot = await _collection.get();
    if (index < snapshot.docs.length) {
      final docId = snapshot.docs[index].id;
      await _collection.doc(docId).delete();
    }
  }

  @override
  Future<List<Cidade>> buscar({String filtro = ''}) async {
    final snapshot = await _collection.get();
    final all = snapshot.docs
        .map(
          (doc) => Cidade.fromMap(Map<String, dynamic>.from(doc.data() as Map)),
        )
        .toList();

    if (filtro.isEmpty) return all;

    return all
        .where(
          (c) =>
              c.nomeCidade.toLowerCase().contains(filtro.toLowerCase()) ||
              c.estado.toLowerCase().contains(filtro.toLowerCase()),
        )
        .toList();
  }
}
