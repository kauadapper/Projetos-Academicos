import 'package:hive_flutter/hive_flutter.dart';
import '../model/cliente.dart';

abstract class IClienteRepository {
  Future<void> inserir(Cliente cliente);
  Future<void> atualizar(int index, Cliente cliente);
  Future<void> excluir(int index);
  Future<List<Cliente>> buscar({String filtro = ''});
}

class ClienteRepository implements IClienteRepository {
  static const String boxName = 'clientes';

  Future<Box> get _box async => await Hive.openBox(boxName);

  @override
  Future<void> inserir(Cliente cliente) async {
    final box = await _box;
    await box.add(cliente.toMap());
  }

  @override
  Future<void> atualizar(int index, Cliente cliente) async {
    final box = await _box;
    await box.putAt(index, cliente.toMap());
  }

  @override
  Future<void> excluir(int index) async {
    final box = await _box;
    await box.deleteAt(index);
  }

  @override
  Future<List<Cliente>> buscar({String filtro = ''}) async {
    final box = await _box;
    final List<Map<String, dynamic>> all = box.values
        .cast<Map<String, dynamic>>()
        .toList();

    final filtered = filtro.isEmpty
        ? all
        : all
              .where(
                (m) => (m['nome'] as String).toLowerCase().contains(
                  filtro.toLowerCase(),
                ),
              )
              .toList();

    return filtered.map((m) => Cliente.fromMap(m)).toList();
  }
}
