import 'package:hive_flutter/hive_flutter.dart';
import '../db/cidade.dart';

abstract class ICidadeRepository {
  Future<void> inserir(Cidade cidade);
  Future<void> atualizar(int index, Cidade cidade);
  Future<void> excluir(int index);
  Future<List<Cidade>> buscar({String filtro = ''});
}

class CidadeRepository implements ICidadeRepository {
  static const String boxName = 'cidades';

  Future<Box> get _box async => await Hive.openBox(boxName);

  @override
  Future<void> inserir(Cidade cidade) async {
    final box = await _box;
    await box.add(cidade.toMap());
  }

  @override
  Future<void> atualizar(int index, Cidade cidade) async {
    final box = await _box;
    await box.putAt(index, cidade.toMap());
  }

  @override
  Future<void> excluir(int index) async {
    final box = await _box;
    await box.deleteAt(index);
  }

  @override
  Future<List<Cidade>> buscar({String filtro = ''}) async {
    final box = await _box;
    final all = box.values
        .map(
          (e) => Map<String, dynamic>.from(
            Map<String, dynamic>.from(e.cast<String, dynamic>()),
          ),
        )
        .toList();

    final filtered = filtro.isEmpty
        ? all
        : all
              .where(
                (m) =>
                    (m['nomeCidade'] as String).toLowerCase().contains(
                      filtro.toLowerCase(),
                    ) ||
                    (m['estado'] as String).toLowerCase().contains(
                      filtro.toLowerCase(),
                    ),
              )
              .toList();

    return filtered.map((m) => Cidade.fromMap(m)).toList();
  }
}
