// models/midia_model.dart
class MidiaModel {
  final String? caminho; // opcional, geralmente null aqui
  final String? base64; // base64 da midia (foto ou video)
  final bool ehVideo;

  MidiaModel({this.caminho, this.base64, required this.ehVideo});
}
