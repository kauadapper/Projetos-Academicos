import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodel/cliente_viewmodel.dart';
import '../viewmodel/cidade_viewmodel.dart';
import '../view/camera_view.dart';
import 'cadastro_cliente_page.dart';
import 'cadastro_cidade_page.dart';
import '../utils/persistence_helper.dart';

class ListaClientesPage extends StatefulWidget {
  const ListaClientesPage({super.key});

  @override
  State<ListaClientesPage> createState() => _ListaClientesPageState();
}

class _ListaClientesPageState extends State<ListaClientesPage> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final clienteVM = Provider.of<ClienteViewModel>(context);
    final cidadeVM = Provider.of<CidadeViewModel>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Clientes (MVVM + Persistencia)')),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.extended(
            icon: const Icon(Icons.location_city),
            label: const Text('Cadastrar Cidade'),
            backgroundColor: Colors.orange,
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CadastroCidadePage()),
              );
            },
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            icon: const Icon(Icons.person_add),
            label: const Text('Cadastrar Cliente'),
            backgroundColor: Colors.blue,
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CadastroClientePage()),
              );
              await clienteVM.loadClientes(_searchController.text);
            },
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            icon: const Icon(Icons.camera_alt),
            label: const Text('Camera'),
            backgroundColor: Colors.green,
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CameraView()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: 'Pesquisar por nome',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (value) async {
                await clienteVM.loadClientes(value);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Persistencia atual: ${clienteVM.usandoFirebase ? "Firebase" : "Banco"}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                ElevatedButton(
                  onPressed: () async {
                    final novoModo = !clienteVM.usandoFirebase;
                    await PersistenceHelper.setUseFirebase(novoModo);

                    await clienteVM.aplicarModo(novoModo);
                    await cidadeVM.aplicarModo(novoModo);

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Modo de persistencia alterado para ${novoModo ? "Firebase" : "Banco"}!',
                        ),
                        duration: const Duration(seconds: 2),
                      ),
                    );
                  },
                  child: const Text('Alternar Persistencia'),
                ),
              ],
            ),
          ),
          Expanded(
            child: clienteVM.clientes.isEmpty
                ? const Center(child: Text('Nenhum cliente encontrado'))
                : ListView.builder(
                    itemCount: clienteVM.clientes.length,
                    itemBuilder: (context, index) {
                      final dto = clienteVM.clientes[index];
                      return ListTile(
                        title: Text(dto.nome),
                        subtitle: Text(dto.subtitulo),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit),
                              onPressed: () async {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        CadastroClientePage(clienteDTO: dto),
                                  ),
                                );
                                await clienteVM.loadClientes(
                                  _searchController.text,
                                );
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () async {
                                await clienteVM.removerCliente(dto.codigo!);
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
