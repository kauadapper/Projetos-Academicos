import 'package:camera/camera.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../viewmodel/camera_viewmodel.dart';
import 'dart:convert';

class CameraView extends StatefulWidget {
  const CameraView({super.key});
  @override
  State<CameraView> createState() => _CameraViewState();
}

class _CameraViewState extends State<CameraView> {
  final CameraViewModel _viewModel = CameraViewModel();
  bool _gravando = false;
  bool _carregando = true;

  @override
  void initState() {
    super.initState();
    _inicializar();
  }

  Future<void> _inicializar() async {
    try {
      await _viewModel.inicializarCamera();
    } catch (e) {
      // caso nao tenha camera, mostra erro simples
      // ignore: avoid_print
      print('Erro inicializar camera: $e');
    } finally {
      setState(() {
        _carregando = false;
      });
    }
  }

  @override
  void dispose() {
    _viewModel.dispose();
    super.dispose();
  }

  Widget _buildPreview() {
    // sem midia: mostra CameraPreview
    if (!_viewModel.temMidia) {
      if (!_viewModel.inicializado) {
        return const SizedBox(height: 250, child: Center(child: Text('Camera nao inicializada')));
      }
      return AspectRatio(
        aspectRatio: _viewModel.controller.value.aspectRatio,
        child: CameraPreview(_viewModel.controller),
      );
    }

    // se for video: mostra info e parte do base64 (debug)
    if (_viewModel.ehVideo) {
      final base64 = _viewModel.base64Midia ?? '';
      final preview = base64.length > 200 ? base64.substring(0, 200) + '...' : base64;
      return Container(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            const Icon(Icons.videocam, size: 64),
            const SizedBox(height: 8),
            Text('Video (base64 length: ${base64.length})', textAlign: TextAlign.center),
            const SizedBox(height: 8),
            SelectableText(preview, style: const TextStyle(fontSize: 10)),
          ],
        ),
      );
    }

    // foto: decodifica base64 e mostra
    final base64 = _viewModel.base64Midia;
    if (base64 == null) return const SizedBox.shrink();
    try {
      final bytes = base64Decode(base64);
      return Image.memory(bytes, height: 250, fit: BoxFit.contain);
    } catch (e) {
      return const Text('Erro ao decodificar imagem');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_carregando) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Camera - MVVM'), backgroundColor: Colors.teal),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildPreview(),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('Tirar Foto'),
                  onPressed: () async {
                    await _viewModel.tirarFoto();
                    setState(() {});
                  },
                ),
                ElevatedButton.icon(
                  icon: Icon(_gravando ? Icons.stop : Icons.videocam),
                  label: Text(_gravando ? 'Parar' : 'Gravar'),
                  onPressed: () async {
                    if (_gravando) {
                      await _viewModel.pararGravacao();
                      setState(() => _gravando = false);
                    } else {
                      await _viewModel.iniciarGravacao();
                      setState(() => _gravando = true);
                    }
                  },
                ),
                ElevatedButton.icon(
  icon: const Icon(Icons.upload),
  label: const Text('Enviar Firebase'),
  onPressed: () async {
    final base64 = _viewModel.base64Midia;
    if (base64 == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nenhuma midia para enviar')),
      );
      return;
    }

    try {
      await FirebaseFirestore.instance.collection('midias').add({
        'base64': base64,
        'tipo': _viewModel.ehVideo ? 'video' : 'foto',
        'data': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Midia enviada para Firebase!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao enviar: $e')),
      );
    }
  },
),

              ],
            ),
          ],
        ),
      ),
    );
  }
}
