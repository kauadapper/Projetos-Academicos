import 'package:exdb/db/cidade.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodel/cidade_viewmodel.dart';

class BuscaCidadePopup extends StatefulWidget {
  const BuscaCidadePopup({super.key});

  @override
  State<BuscaCidadePopup> createState() => _BuscaCidadePopupState();
}

class _BuscaCidadePopupState extends State<BuscaCidadePopup> {
  final TextEditingController _filtroController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final vm = Provider.of<CidadeViewModel>(context);

    return SizedBox(
      width: 300,
      height: 400,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            const Text('Buscar Cidade', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            TextField(
              controller: _filtroController,
              decoration: const InputDecoration(
                labelText: 'Digite o nome da cidade',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) => vm.loadCidades(value),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: vm.cidades.length,
                itemBuilder: (context, index) {
                  final Cidade c = vm.cidades[index];
                  return ListTile(
                    title: Text(c.nomeCidade),
                    trailing: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context, c.nomeCidade);
                      },
                      child: const Text('Selecionar'),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
