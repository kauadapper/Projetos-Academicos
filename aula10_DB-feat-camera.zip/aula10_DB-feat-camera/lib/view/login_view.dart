import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodel/auth_viewmodel.dart';
import 'lista_cliente.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    final authVM = Provider.of<AuthViewModel>(context);

    if (authVM.user != null) {
      Future.microtask(() {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const ListaClientesPage()),
        );
      });
    }

    return Scaffold(
      appBar: AppBar(title: const Text("Login")),
      body: Center(
        child: ElevatedButton.icon(
          icon: const Icon(Icons.login),
          label: const Text("Entrar com Google"),
          onPressed: () async {
            await authVM.loginWithGoogle();

            if (authVM.user != null) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const ListaClientesPage()),
              );
            } else {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text("Falha no login")));
            }
          },
        ),
      ),
    );
  }
}
